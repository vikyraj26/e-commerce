from django.urls import path
from .views import home , signup , login , cart ,check_out,orders
from .views.login import logout
from .middlewares.auth import auth_middleware




urlpatterns = [
    path('', home.Home.as_view(),name="home"),
    path('signup/',signup.Signup.as_view(),name="signup"),
    path('userlogin/',login.Login.as_view(),name="userlogin"),
    path('logout/',logout,name="logout"),
    path('cart/',cart.Cart.as_view(),name="cart"),
    path('check-out/',check_out.Check_out.as_view(),name="Check_out"),
    path('orders/',auth_middleware(orders.Orders.as_view()),name="orders")
]