from django.shortcuts import render,redirect
from django.http import HttpResponse , Http404,HttpResponseRedirect
from django.contrib.auth.hashers import make_password,mask_hash,check_password
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.views import View

# Create your views here.

class Home(View):
    def get(self,request):
        cart=request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        products = None       
        categories = Category.get_all_category()
        catId = request.GET.get('category')
        if catId:
            products = Product.get_all_products_by_categoryid(catId)
        else:
            products = Product.get_all_products()
            
        useremail = request.session.get('customeremail')
        return render(request,'index.html',{'allproduct':products,'allcat':categories,'email':useremail})
    
    def post(self,request):
        if request.method=='POST':
            product = request.POST.get('productid')
            productqtyremove = request.POST.get('productqtyremove')
            
            cart = request.session.get('cart')
            if cart:
                qty=cart.get(product)
                if qty:
                    if productqtyremove:
                        if qty==1:
                            cart.pop(product)
                        else:    
                            cart[product]=qty-1
                    else:
                        cart[product]=qty+1
                else:
                    cart[product]=1
            else:
                cart={}
                cart[product]=1
                
            request.session['cart']=cart
            return redirect('home')
