from django.shortcuts import render,redirect
from django.http import HttpResponse , Http404,HttpResponseRedirect
from django.contrib.auth.hashers import make_password,mask_hash,check_password
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.views import View


class Signup(View):
    def get(self, request):   
        return render(request,'signup.html')
    
    
    def post(self,request):
        if request.method == 'POST':
            finame = request.POST.get('username')
            lusername = request.POST.get('lusername')
            email = request.POST.get('email')
            password = request.POST.get('password')
            phone = request.POST.get('phone')
            #validation
            error_message = ''
            valuedes ={
                'fname':finame,
                'lname':lusername,
                'email':email,
                'phone':phone
            }
            if(not finame):
                error_message ="First name is required !"
            elif len(finame) < 4:
                error_message = 'First name must be 4 char logn'
            elif not phone:
                error_message='Mobile is required !'
            elif len(phone) <10:
                error_message = 'Mobile number must be equels to 10'
            elif not email:
                error_message ='Email is required !'
            elif not lusername:
                error_message='Last name is required !'
            elif not password:
                error_message ='Password is required'
            elif len(password) < 8:
                error_message='Password lenght must be 8 char'
            elif Customer.isExist(email):
                error_message='Email id already exist'
                
            if not error_message:
                customer = Customer(first_name=finame,last_name=lusername,phone=phone,email=email,password=make_password(password))
                
                customer.register()
                return redirect('home')
            else:
                return render(request,'signup.html',{'error':error_message,'values':valuedes})
