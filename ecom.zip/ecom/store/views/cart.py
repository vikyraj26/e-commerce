from django.shortcuts import render,redirect
from django.http import HttpResponse , Http404,HttpResponseRedirect
from django.contrib.auth.hashers import make_password,mask_hash,check_password
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.views import View



class Cart(View):
    def get(self,  request):
        ids= list(request.session.get('cart').keys())
        data = Product.get_product_byId(ids)
        return render(request,'cart.html',{'product':data})
    

    