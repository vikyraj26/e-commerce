from django.shortcuts import render,redirect
from django.http import HttpResponse , Http404,HttpResponseRedirect
from django.contrib.auth.hashers import make_password,mask_hash,check_password
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from store.models.orders import Order
from django.views import View



class Check_out(View):
    def post(self,  request):
        address = request.POST.get('address')
        mobile = request.POST.get('mobile')
        customer = request.session.get('customerid')
        cart = request.session.get('cart')
        products = Product.get_product_byId(list(cart.keys()))
        for product in products:
            print(cart.get(str(product.id)))
            order = Order(customer=Customer(id=customer),
                          product=product,
                          price=product.price,
                          address=address,
                          phone=mobile,
                          quantity=cart.get(str(product.id)))
            order.save()
        request.session['cart'] = {}
        return redirect('cart')
    

    