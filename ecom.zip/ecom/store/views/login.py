from django.shortcuts import render,redirect
from django.http import HttpResponse , Http404,HttpResponseRedirect
from django.contrib.auth.hashers import make_password,mask_hash,check_password
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.views import View



class Login(View):
    returnUrl =''
    def get(self,  request):
        Login.returnUrl = request.GET.get('returnUrl')
        return render(request,'loginpage.html')
    
    
    def post(self,request):        
        email =request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.getUserbyEmail(email)
        error_message = None
        if customer:
            if(check_password(password,customer.password)):
                request.session['customerid']=customer.id
                request.session['customeremail']=customer.email
                
                return redirect('home')
            else:
                error_message="Email and password missmatch"
        else:
            error_message="Email and password missmatch"
            
        return render(request,'loginpage.html',{'error':error_message})
    

def logout(request):
    request.session.clear()
    return redirect('userlogin')
    
    