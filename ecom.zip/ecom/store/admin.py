from django.contrib import admin

# Register your models here.
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
from .models.orders import Order
# Register your models here.
# @admin.register(Product)


class AdminProduct(admin.ModelAdmin):
    list_display = ['name','price','category']


class AdminCatagory(admin.ModelAdmin):
    list_display = ['id','cname']
    
class AdminCustomer(admin.ModelAdmin):
    list_display = ['id','first_name','last_name','email','phone']
    
class AdminOrder(admin.ModelAdmin):
    list_display = ['id','product','customer','quantity','address','phone']
    
    
admin.site.register(Product,AdminProduct)
admin.site.register(Category,AdminCatagory)  
admin.site.register(Customer,AdminCustomer)   
admin.site.register(Order,AdminOrder) 

# class AdminProduct(admin.ModelAdmin):
#     list_display = ('id','name','price')

# class AdminCatagory(admin.ModelAdmin):
#     list_display = ('id','cname')