from django.db import models

class Category(models.Model):
    cname = models.CharField(max_length=100)
    
    def __str__(self):
        return self.cname
    
    @staticmethod
    def get_all_category():
        return  Category.objects.all()