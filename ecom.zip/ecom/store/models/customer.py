from django.db import models

class Customer(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=150)
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    password = models.CharField(max_length=500)
    
    def __str__(self):
        return self.first_name
    
    def register(self):
        self.save()
    
    def isExist(uemail):
        if Customer.objects.filter(email = uemail):
            return True
        else:
            return False
    
    @staticmethod
    def getUserbyEmail(email):
        try:
            return  Customer.objects.get(email = email)
        except:
            return False
        