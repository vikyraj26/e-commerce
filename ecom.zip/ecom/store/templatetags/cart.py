from django import template

register = template.Library()

@register.filter(name='is_in_cart')
def is_in_cart(product , cart):
    if cart:
        key = cart.keys()
        # print(keys)
        for id in key:
            if int(id) == product.id:
                return True
    # print(product,cart)
    return False


@register.filter(name='cart_count')
def cart_count(product , cart):
    if cart:
        key = cart.keys()
        # print(keys)
        for id in key:
            if int(id) == product.id:
                return cart.get(id)
    # print(product,cart)
    return 0
@register.filter(name='price_total')
def price_total(product , cart):
    return product.price * cart_count(product , cart)

@register.filter(name="total_price")
def total_price(product , cart):
    sum = 0
    for p in product:
        sum += price_total(p , cart) 
    return sum